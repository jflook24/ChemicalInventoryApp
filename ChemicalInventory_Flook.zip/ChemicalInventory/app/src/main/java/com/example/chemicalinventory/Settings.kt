package com.example.chemicalinventory

import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.TextUtils
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main2.*
import kotlinx.android.synthetic.main.activity_settings.*

class Settings : AppCompatActivity() {
    val PREF_Name="myPrefs"
    var myPref:SharedPreferences?=null
    val LAST_Name="lastname"
    var lastname:SharedPreferences?=null
    val Location="location"
    var location:SharedPreferences?=null
    val Email ="email"
    var email:SharedPreferences?=null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        save_button.setOnClickListener {
            myPref = getSharedPreferences(PREF_Name, 0)
            lastname = getSharedPreferences(LAST_Name, 0)
            location = getSharedPreferences(Location, 0)
            email = getSharedPreferences(Email, 0)
            var editor: SharedPreferences.Editor = (myPref as SharedPreferences).edit()
            //var editor: SharedPreferences.Editor = (lastname as SharedPreferences).edit()
            if (!TextUtils.isEmpty(firstname_input.text.toString())) {
                editor.putString("myPrefs", firstname_input.text.toString())
                editor.commit()
                editor.putString("lastname", lastname_input.text.toString())
                editor.commit()
                editor.putString("location", location_input.text.toString())
                editor.commit()
                editor.putString("email", email_input.text.toString())
                editor.commit()
                var intent =Intent(this, MainActivity2::class.java)
                startActivity(intent)
            } else {
                Toast.makeText(this, "Please Enter your information", Toast.LENGTH_LONG).show()
            }
        }
        //var databack: SharedPreferences = getSharedPreferences(PREF_Name, 0)
        //databack = getSharedPreferences(PREF_Name, 0)
        //if (databack.contains("message")) {
            //firstname_result.text = databack.getString("message", "not found")
            //lastname_result.text = databack.getString("message", "not found")
            //location_result.text = databack.getString("message", "not found")
        }

        fun Go2mainActivity2(view: View){
        var intent=Intent(this, MainActivity2::class.java)
        //intent.putExtra("firstname", firstname_input.text.toString())
        //intent.putExtra("lastname", lastname_input.text.toString())
        //intent.putExtra("location", location_input.text.toString())
        //intent.putExtra("email", email_input.text.toString())
        startActivity(intent)
    }
    override fun onCreateOptionsMenu(menu: Menu?):  Boolean {
        menuInflater.inflate(R.menu.menu, menu)
        return true
    }
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item?.itemId) {

            R.id.item1 -> {
                var intent = Intent(this, MainActivity2::class.java)
                startActivity(intent)
                return super.onOptionsItemSelected(item)
            }
            R.id.item2 -> {
                var intent = Intent(this, ChemList::class.java)
                startActivity(intent)
                return super.onOptionsItemSelected(item)
            }
            R.id.item3 -> {
                var intent = Intent(this, ChemicalAdd::class.java)
                startActivity(intent)
                return super.onOptionsItemSelected(item)
            }
            R.id.item4 -> {
                var intent = Intent(this, Settings::class.java)
                startActivity(intent)
                return super.onOptionsItemSelected(item)
            }
            R.id.item5 -> {
                var intent = Intent(this, Settings::class.java)
                startActivity(intent)
                return super.onOptionsItemSelected(item)
            }
            R.id.item6 -> {
                var intent = Intent(this, Help::class.java)
                startActivity(intent)
                return super.onOptionsItemSelected(item)
            }
            else -> return super.onOptionsItemSelected(item)
        }

    }}
