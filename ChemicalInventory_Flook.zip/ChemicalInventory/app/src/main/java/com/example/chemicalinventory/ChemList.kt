package com.example.chemicalinventory

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.ArrayAdapter
import kotlinx.android.synthetic.main.activity_chem_list.*

class ChemList : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chem_list)

        var chemicalname:Array<String> = arrayOf("Chem 1", "Chem2", "Chem3", "Chem 4")

        var chemicalnameAdapter: ArrayAdapter<String> = ArrayAdapter(this,android.R.layout.simple_list_item_1, chemicalname)
        chem_list.adapter=chemicalnameAdapter
    }
    override fun onCreateOptionsMenu(menu: Menu?):  Boolean {
        menuInflater.inflate(R.menu.menu, menu)
        return true
    }
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item?.itemId) {

            R.id.item1 -> {
                var intent = Intent(this, MainActivity2::class.java)
                startActivity(intent)
                return super.onOptionsItemSelected(item)
            }
            R.id.item2 -> {
                var intent = Intent(this, ChemList::class.java)
                startActivity(intent)
                return super.onOptionsItemSelected(item)
            }
            R.id.item3 -> {
                var intent = Intent(this, ChemicalAdd::class.java)
                startActivity(intent)
                return super.onOptionsItemSelected(item)
            }
            R.id.item4 -> {
                var intent = Intent(this, Settings::class.java)
                startActivity(intent)
                return super.onOptionsItemSelected(item)
            }
            R.id.item5 -> {
                var intent = Intent(this, Settings::class.java)
                startActivity(intent)
                return super.onOptionsItemSelected(item)
            }
            R.id.item6 -> {
                var intent = Intent(this, Help::class.java)
                startActivity(intent)
                return super.onOptionsItemSelected(item)
            }
            else -> return super.onOptionsItemSelected(item)
        }

    }
}
