package com.example.chemicalinventory

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.MediaStore
import android.view.Menu
import android.view.MenuItem
import android.widget.ArrayAdapter
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.core.app.ActivityCompat
import androidx.core.view.GravityCompat
import kotlinx.android.synthetic.main.activity_chem_list.*
import kotlinx.android.synthetic.main.activity_chemical_add.*
import kotlinx.android.synthetic.main.activity_main2.*

class ChemicalAdd : AppCompatActivity() {
    private var mDbAdapter: MyDBAdapter? = null
    private val mAllFaculties = arrayOf("Herbicide", "Insecticide", "Fungicide")


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chemical_add)
        initializeViews()
        initializeDatabase()
        loadList()

        scan_button.isEnabled = false
        if(ActivityCompat.checkSelfPermission(this, Manifest.permission.CAMERA) !=
            PackageManager.PERMISSION_GRANTED){
                ActivityCompat.requestPermissions(this,arrayOf(Manifest.permission.CAMERA), 111)
        }
        else
            scan_button.isEnabled = true
        scan_button.setOnClickListener {
            var i = Intent (MediaStore.ACTION_IMAGE_CAPTURE)
            startActivityForResult(i, 101)}


    }
    override fun onRequestPermissionsResult(requestCode: Int,permissions: Array<out String>,grantResults:
    IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 111 && grantResults[0] == PackageManager.PERMISSION_GRANTED)
        {
            scan_button.isEnabled = true
        }}
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == 101) {
            var pic: Bitmap? = data?.getParcelableExtra<Bitmap>("data")
            barcode_image.setImageBitmap(pic)
        }
    }

        override fun onCreateOptionsMenu(menu: Menu?):  Boolean {
        menuInflater.inflate(R.menu.menu, menu)
        return true
    }
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item?.itemId) {

            R.id.item1 -> {
                var intent = Intent(this, MainActivity2::class.java)
                startActivity(intent)
                return super.onOptionsItemSelected(item)
            }
            R.id.item2 -> {
                var intent = Intent(this, ChemList::class.java)
                startActivity(intent)
                return super.onOptionsItemSelected(item)
            }
            R.id.item3 -> {
                var intent = Intent(this, ChemicalAdd::class.java)
                startActivity(intent)
                return super.onOptionsItemSelected(item)
            }
            R.id.item4 -> {
                var intent = Intent(this, Settings::class.java)
                startActivity(intent)
                return super.onOptionsItemSelected(item)
            }
            R.id.item5 -> {
                var intent = Intent(this, Settings::class.java)
                startActivity(intent)
                return super.onOptionsItemSelected(item)
            }
            R.id.item6 -> {
                var intent = Intent(this, Help::class.java)
                startActivity(intent)
                return super.onOptionsItemSelected(item)
            }
            else -> return super.onOptionsItemSelected(item)
        }

    }

    override fun onNavigationItemSelected(item: MenuItem):  Boolean {
        R.layout.closeDrawer(GravityCompat.START)
        return true
    }

    private fun initializeViews() {
        setSupportActionBar(toolbar)
        val toggle = ActionBarDrawerToggle(this,
                R.layout,
                toolbar,
                R.string.navigation_drawer_open,
                R.string.navigation_drawer_close)
        R.layout.addDrawerListener(toggle)
        toggle.syncState()
        nav_view.setNavigationItemSelectedListener(this)

        type_spinner.adapter = ArrayAdapter(this@chemical_add,
                android.R.layout.simple_list_item_1,
                mAllFaculties)
        add_button.setOnClickListener {
            mDbAdapter?.insertChemicals(chem_name.text.toString(),
                    type_spinner.selectedItemPosition + 1)
            loadList()
        }

    }
    private fun initializeDatabase() {
        mDbAdapter = MyDBAdapter(this@chemical_add)
        mDbAdapter?.open()
    }
    private fun loadList(){
        val allStudents: List<String>? = mDbAdapter?.selectAllChemicals()
        val adapter = ArrayAdapter(
                this@chemical_add,
                android.R.layout.simple_list_item_1,
                allStudents!!)
        chem_list.adapter = adapter
    }
}

