package com.example.chemicalinventory

import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.*
import androidx.appcompat.app.ActionBarDrawerToggle
import kotlinx.android.synthetic.main.activity_main2.*

class MainActivity2 : AppCompatActivity() {
    val PREF_Name="myPrefs"
    var myPref:SharedPreferences?=null
    val LAST_Name="lastname"
    var lastname:SharedPreferences?=null
    val Location="location"
    var location:SharedPreferences?=null
    val Email ="email"
    var email:SharedPreferences?=null

    private var mDbAdapter: MyDBAdapter? = null

override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    setContentView(R.layout.activity_main2)

    var databack: SharedPreferences = getSharedPreferences(PREF_Name, 0)
    databack = getSharedPreferences(PREF_Name, 0)
    if (databack.contains("message")) {
        firstname_result.text = databack.getString("myPrefs", "not found")
        lastname_result.text = databack.getString("lastname", "not found")
        location_result.text = databack.getString("location", "not found")
        //var firstname = intent.getStringExtra("firstname")
        //firstname_result.text = firstname
        //var lastname = intent.getStringExtra("lastname")
        //lastname_result.text = lastname
        //var location = intent.getStringExtra("location")
        //location_result.text = location
    }
}

    fun Go2chemicaladdActivity(view: View) {
        var intent =Intent(this, ChemicalAdd::class.java)
        startActivity(intent)


    }
    override fun onCreateOptionsMenu(menu: Menu?):  Boolean {
        menuInflater.inflate(R.menu.menu, menu)
        return true
    }
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item?.itemId) {

            R.id.item1 -> {
                var intent = Intent(this, MainActivity2::class.java)
                startActivity(intent)
                return super.onOptionsItemSelected(item)
            }
            R.id.item2 -> {
                var intent = Intent(this, ChemList::class.java)
                startActivity(intent)
                return super.onOptionsItemSelected(item)
            }
            R.id.item3 -> {
                var intent = Intent(this, ChemicalAdd::class.java)
                startActivity(intent)
                return super.onOptionsItemSelected(item)
            }
            R.id.item4 -> {
                var intent = Intent(this, Settings::class.java)
                startActivity(intent)
                return super.onOptionsItemSelected(item)
            }
            R.id.item5 -> {
                var intent = Intent(this, Settings::class.java)
                startActivity(intent)
                return super.onOptionsItemSelected(item)
            }
            R.id.item6 -> {
                var intent = Intent(this, Help::class.java)
                startActivity(intent)
                return super.onOptionsItemSelected(item)
            }
            else -> return super.onOptionsItemSelected(item)
        }
    }}