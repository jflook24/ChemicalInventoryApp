package com.example.chemicalinventory.ui.login

import android.app.Activity
import android.content.Intent
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import android.os.Bundle
import androidx.annotation.StringRes
import androidx.appcompat.app.AppCompatActivity
import android.text.Editable
import android.text.TextWatcher
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.Toast
import com.example.chemicalinventory.*
import kotlinx.android.synthetic.main.activity_main.*

import kotlinx.android.synthetic.main.activity_login.*

class LoginActivity : AppCompatActivity() {

    private lateinit var loginViewModel: LoginViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        login.setOnClickListener { onLoginButtonClicked(this.login) }
    }

    fun onLoginButtonClicked(view: View) {
        var username = username.text.toString()
        var password = password.text.toString()
        if (username.equals("test") && password.equals("111111")) {   //making a valid user
            var intent = Intent(this, MainActivity2::class.java)
            startActivity(intent)
            Toast.makeText(this,"Login Successful", Toast.LENGTH_LONG).show()
            //put something here for success

        } else {
            //failure code here
            Toast.makeText(this, "Login Failed, Please try again", Toast.LENGTH_LONG).show()
        }}}